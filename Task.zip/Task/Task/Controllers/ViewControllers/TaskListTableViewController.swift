//
//  TaskListTableViewController.swift
//  Task
//
//  Created by Nevan Bingham on 7/21/21.
//

import UIKit

class TaskListTableViewController: UITableViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        TaskController.shared.loadFromPersistenceStore()
    }

    override func viewWillAooear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        tableView.reloadData()
    }
    
    var tast: Task?
    
    
    
    
    
    
    // MARK: - Table view data source


    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return 0
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "reuseIdentifier", for: indexPath)

        return cell
    }
    


    
    
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
           
            guard let task = task else { return  }
            let taskToDelete = task.[indexPath.row]
            
            tableView.deleteRows(at: [indexPath], with: .fade)
        
        }
            
        }    
    }
    

   

    
    // MARK: - Navigation

    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        guard let destination = segue.destination as? TaskDetailViewController,
              let task = task else { return }
        if segue.identifier == "toTaskDetailVC" {
            guard let indexPath = tableView.indexPathForSelectedRow else { return }
            
            let taskToSend = task.task[indexPath.row]
            destination.task = taskToSend
    }
    

}
