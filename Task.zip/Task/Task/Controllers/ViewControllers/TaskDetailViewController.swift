//
//  TaskDetailViewController.swift
//  Task
//
//  Created by Nevan Bingham on 7/21/21.
//

import UIKit

class TaskDetailViewController: UIViewController {

    @IBOutlet weak var taskNameTextField: UITextField!
    @IBOutlet weak var taskNotesTextView: UITextView!
    @IBOutlet weak var taskDueDatePicker: UIDatePicker!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    @IBAction func saveButtonTapped(_ sender: Any) {
    }
    @IBAction func dueDatePickerChanged(_ sender: Any) {
    }
    

    

}
