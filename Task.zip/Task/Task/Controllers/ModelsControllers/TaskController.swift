//
//  TaskController.swift
//  Task
//
//  Created by Nevan Bingham on 7/21/21.
//

import Foundation


class TaskController {
    
    //Shared Instance
    static let shared = TaskController()
    
    //Source of Truth
    var tasks: [Task] = []
    
    func createTaskWith(name: String, notes: String?, dueDate: Date?) {
        
        let newTask = Task(name: name, notes: notes, dueDate: dueDate)
        tasks.append(newTask)
        
        TaskController.shared.saveToPersistenceStore()
    }
    
    
    
    func delete(task: Task) {
        guard let index = tasks.firstIndex(of: task) else { return }
        tasks.remove(at: index)
        
        TaskController.shared.saveToPersistenceStore()
    }
    
    
    func toggleIsComplete(task: Task) {
        task.isComplete.toggle()
        
        TaskController.shared.saveToPersistenceStore()
    }
    
    func update(task: Task, name: String, notes: String?, dueDate: Date?) {
        
        task.name = name
        task.notes = notes
        task.dueDate = dueDate
        
        TaskController.shared.saveToPersistenceStore()
    }

    func createToPersistenceStore() -> URL {
     let urls = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
     let documentsDirectoryURL = urls[0].appendingPathComponent("Task.json")
     return documentsDirectoryURL
    }

    func saveToPersistenceStore() {
        do {
            let data = try JSONEncoder().encode(tasks)
            try data.write(to: createToPersistenceStore())
        } catch {
            print("Error in \(#function) : \(error.localizedDescription) \n---\n \(error)")
        }
    }

    func loadFromPersistenceStore() {
        do {
            let data = try Data(contentsOf: createToPersistenceStore())
            tasks = try JSONDecoder().decode([Task].self, from: data)
        } catch {
            print("Error in \(#function) : \(error.localizedDescription) \n---\n \(error)")
        }
    }

}

